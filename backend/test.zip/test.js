const open = import('open')

open('https://google.com')